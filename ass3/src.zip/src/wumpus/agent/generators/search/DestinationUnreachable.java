package wumpus.agent.generators.search;

public class DestinationUnreachable extends Exception {
}
