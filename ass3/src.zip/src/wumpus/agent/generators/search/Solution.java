package wumpus.agent.generators.search;

public abstract class Solution {
}
