package wumpus.agent.generators;

public class NoFeasiblePolicyFound extends Exception {
}
