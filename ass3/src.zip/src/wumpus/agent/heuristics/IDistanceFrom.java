package wumpus.agent.heuristics;

import javax.vecmath.Point2i;

public interface IDistanceFrom {

    double compute(Point2i a);

}
