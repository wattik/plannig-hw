package wumpus.agent.policy;

public class NoPolicyForThisState extends Exception {
}
