package wumpus.world;

public enum CellContent {EMPTY, OBSTACLE, GOLD, PIT, REDKEY, BLUEKEY, REDDOOR, BLUEDOOR}